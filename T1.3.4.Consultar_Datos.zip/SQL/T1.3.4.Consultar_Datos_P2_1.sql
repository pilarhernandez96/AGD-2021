SELECT DISTINCT --te.id_role,
r.role,
MIN(te.count_id_indexed) OVER (PARTITION BY te.id_role) AS Demanda_Minima
from Tasas_Empleo te
LEFT JOIN Role r on te.id_role=r.id_role
Where strftime('%Y', te.post_date) = '2020'
and strftime('%m', te.post_date) <= '06'
and te.id_State = 1
order by 2 ASC
limit 20

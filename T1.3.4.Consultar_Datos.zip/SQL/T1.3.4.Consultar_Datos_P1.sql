SELECT DISTINCT gi.state,
--te.id_State,
--te.id_Indt,
 i.industry,
--gi.state,
min(te.count_id_indexed) over (partition by te.id_Indt,te.id_State) as Minimo
FROM Tasas_Empleo te
left join geography_industry gi on te.id_State = gi.ID_STATE
left join industry i on te.id_Indt = i.ID

where te.id_State = 1
and strftime('%Y', te.post_date) = '2020'
and strftime('%m', te.post_date) <= '06' 

ORDER by 1,3 ASC
limit 5

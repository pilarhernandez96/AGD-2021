SELECT 
jfr.job_family,
--MIN(te.count_id_indexed) OVER (PARTITION BY te.id_job_family) AS Demanda_Minima
min(te.count_id_indexed) as Demanda_Minima
from Tasas_Empleo te
LEFT JOIN job_family_role jfr on te.id_role=jfr.Id_job_family
Where strftime('%Y', te.post_date) = '2020'
and strftime('%m', te.post_date) <= '06'
and te.id_State = 1
and jfr.job_family is not null
group by 1
order by 2 ASC
limit 10

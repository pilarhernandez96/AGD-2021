DROP TABLE IF EXISTS "Role";
CREATE TABLE [Role] (
  [id_role] Int primary key,
  [Role] Varchar(100),
);

DECLARE @xdoc xml   
SET @xdoc='
<Bases>
<base id_role="1"  role="Call Center Manager"></base>
<base id_role="2"  role="Customer Service Manager"></base>
<base id_role="3"  role="Customer Service Representative"></base>
<base id_role="4"  role="Customer Support Representative"></base>
<base id_role="5"  role="Relationship Manager"></base>
<base id_role="6"  role="Senior Customer Service Representative"></base>
<base id_role="7"  role="Service Desk Manager"></base>
<base id_role="8"  role="Service Manager"></base>
<base id_role="9"  role="Service Representative"></base>
<base id_role="10"  role="Actor"></base>
<base id_role="11"  role="Animal Handler"></base>
<base id_role="12"  role="Animator"></base>
<base id_role="13"  role="Arcade Attendant"></base>
<base id_role="14"  role="Artisan"></base>
<base id_role="15"  role="Artistic Director"></base>
<base id_role="16"  role="Athletic Trainer"></base>
<base id_role="17"  role="Audio Specialist"></base>
<base id_role="18"  role="Box Office Manager"></base>
<base id_role="19"  role="Camera Operator"></base>
<base id_role="20"  role="Camp Director"></base>
<base id_role="21"  role="Camp Staff"></base>
<base id_role="22"  role="Cast Member"></base>
<base id_role="23"  role="Cinematographer"></base>
<base id_role="24"  role="Composer"></base>
<base id_role="25"  role="Curator"></base>
<base id_role="26"  role="Development Assistant"></base>
<base id_role="27"  role="Dresser"></base>
<base id_role="28"  role="Editor"></base>
<base id_role="29"  role="Effects Specialist"></base>
<base id_role="30"  role="Ensemble"></base>
<base id_role="31"  role="Event Manager/Planner"></base>
<base id_role="32"  role="Event Specialist/Staff"></base>
<base id_role="33"  role="Experience Specialist"></base>
<base id_role="34"  role="First Hand"></base>
<base id_role="35"  role="Floor Staff"></base>
<base id_role="36"  role="Game Designer"></base>
<base id_role="37"  role="Golf Cart Attendant"></base>
<base id_role="38"  role="Golf Operations Staff"></base>
<base id_role="39"  role="Grant Writer"></base>
<base id_role="40"  role="Group Leader"></base>
<base id_role="41"  role="Host/ess"></base>
<base id_role="42"  role="Lifeguard"></base>
<base id_role="43"  role="Lighting Designer"></base>
<base id_role="44"  role="Magician"></base>
<base id_role="45"  role="Makeup Artist"></base>
<base id_role="46"  role="Makeup Specialist"></base>
<base id_role="47"  role="Membership Coordinator"></base>
<base id_role="48"  role="Membership Manager"></base>
<base id_role="49"  role="Modeler"></base>
<base id_role="50"  role="Moderator"></base>
<base id_role="51"  role="Musician"></base>
<base id_role="52"  role="Naturalist"></base>
<base id_role="53"  role="News Anchor"></base>
<base id_role="54"  role="Park Manager"></base>
<base id_role="55"  role="Park Ranger"></base>
<base id_role="56"  role="Performer"></base>
<base id_role="57"  role="Personal Assistant"></base>
<base id_role="58"  role="Personal Trainer"></base>
<base id_role="59"  role="Production Assistant"></base>
<base id_role="60"  role="Production Staff"></base>
<base id_role="61"  role="Production Team Member"></base>
<base id_role="62"  role="Production Technician"></base>
<base id_role="63"  role="Promotions Manager"></base>
<base id_role="64"  role="Recreation Specialist"></base>
<base id_role="65"  role="Rental Coordinator"></base>
<base id_role="66"  role="Reporter"></base>
<base id_role="67"  role="Research Specialist"></base>
<base id_role="68"  role="Ride Attendant"></base>
<base id_role="69"  role="Ride Operator"></base>
<base id_role="70"  role="Runner"></base>
<base id_role="71"  role="Seamstress"></base>
<base id_role="72"  role="Ski Instructor"></base>
<base id_role="73"  role="Ski Lift Operator"></base>
<base id_role="74"  role="Sports Coordinator"></base>
<base id_role="75"  role="Stage Manager"></base>
<base id_role="76"  role="Stitcher"></base>
<base id_role="77"  role="Studio Manager"></base>
<base id_role="78"  role="Stylist"></base>
<base id_role="79"  role="Talent Agent"></base>
<base id_role="80"  role="Technical Designer"></base>
<base id_role="81"  role="Technical Manager"></base>
<base id_role="82"  role="Tour Guide"></base>
<base id_role="83"  role="Usher"></base>
<base id_role="84"  role="Video Producer"></base>
<base id_role="85"  role="Video Technician"></base>
<base id_role="86"  role="Videographer"></base>
<base id_role="87"  role="Visitor Services Specialist"></base>
<base id_role="88"  role="Volunteer Coordinator"></base>
<base id_role="89"  role="Writer"></base>
<base id_role="90"  role="Youth Development Specialist"></base>
<base id_role="91"  role="Building Inspector"></base>
<base id_role="92"  role="Building Supervisor"></base>
<base id_role="93"  role="Caretaker"></base>
<base id_role="94"  role="Cleaning Crew"></base>
<base id_role="95"  role="Community Manager"></base>
<base id_role="96"  role="Concrete Laborer"></base>
<base id_role="97"  role="Construction Assistant"></base>
<base id_role="98"  role="Construction Engineer"></base>
<base id_role="99"  role="Construction Foreman"></base>
<base id_role="100"  role="Construction Manager"></base>
<base id_role="101"  role="Construction Worker"></base>
<base id_role="102"  role="Custodian"></base>
<base id_role="103"  role="Environmental Specialist"></base>
<base id_role="104"  role="Facilities Manager"></base>
<base id_role="105"  role="Facilities Technician"></base>
<base id_role="106"  role="Flagger"></base>
<base id_role="107"  role="Gardener"></base>
<base id_role="108"  role="General Maintenance Worker"></base>
<base id_role="109"  role="Groundskeeper/Crew"></base>
<base id_role="110"  role="Janitor"></base>
<base id_role="111"  role="Landscaper"></base>
<base id_role="112"  role="Lawn Technician"></base>
<base id_role="113"  role="Lead Maintenance"></base>
<base id_role="114"  role="Maintenance Crew"></base>
<base id_role="115"  role="Maintenance Electrician"></base>
<base id_role="116"  role="Maintenance Engineer"></base>
<base id_role="117"  role="Maintenance Manager"></base>
<base id_role="118"  role="Maintenance Person"></base>
<base id_role="119"  role="Maintenance Planner"></base>
<base id_role="120"  role="Maintenance Supervisor"></base>
<base id_role="121"  role="Maintenance Technician"></base>
<base id_role="122"  role="Maintenance Worker"></base>
<base id_role="123"  role="Pest Control Technician"></base>
<base id_role="124"  role="Property Manager"></base>
<base id_role="125"  role="Pruner"></base>
<base id_role="126"  role="Sanitation Worker"></base>
<base id_role="127"  role="Utility Worker"></base>
<base id_role="128"  role="Accountant"></base>
<base id_role="129"  role="Accounting Manager"></base>
<base id_role="130"  role="Accounting Specialist"></base>
<base id_role="131"  role="Accounts Payable Specialist"></base>
<base id_role="132"  role="Accounts Receivable Specialist"></base>
<base id_role="133"  role="Actuary"></base>
<base id_role="134"  role="Administrative Assistant"></base>
<base id_role="135"  role="Agency Owner"></base>
<base id_role="136"  role="Analyst"></base>
<base id_role="137"  role="Apartment Manager"></base>
<base id_role="138"  role="Appraiser"></base>
<base id_role="139"  role="Appraiser Trainee"></base>
<base id_role="140"  role="Asset Management Specialist"></base>
<base id_role="141"  role="Asset Manager"></base>
<base id_role="142"  role="Audit Associate"></base>
<base id_role="143"  role="Audit Manager"></base>
<base id_role="144"  role="Auditor"></base>
<base id_role="145"  role="Bail Bondsman"></base>
<base id_role="146"  role="Bank Manager"></base>
<base id_role="147"  role="Banker"></base>
<base id_role="148"  role="Biller"></base>
<base id_role="149"  role="Branch Manager"></base>
<base id_role="150"  role="Broker"></base>
<base id_role="151"  role="Business Intelligence Specialist"></base>
<base id_role="152"  role="Business Systems Analyst"></base>
<base id_role="153"  role="Cash Management Specialist"></base>
<base id_role="154"  role="Certified Financial Planner"></base>
<base id_role="155"  role="Certified Public Accountant"></base>
<base id_role="156"  role="CFO"></base>
<base id_role="157"  role="Chief Accounting Officer"></base>
<base id_role="158"  role="Chief Compliance Officer"></base>
<base id_role="159"  role="Claims Adjuster"></base>
<base id_role="160"  role="Claims Specialist"></base>
<base id_role="161"  role="Clerk"></base>
<base id_role="162"  role="Closer"></base>
<base id_role="163"  role="Collections Specialist"></base>
<base id_role="164"  role="Commercial Property Manager"></base>
<base id_role="165"  role="Commercial Real Estate Agent"></base>
<base id_role="166"  role="Compliance Analyst"></base>
<base id_role="167"  role="Compliance Manager"></base>
<base id_role="168"  role="Compliance Officer"></base>
<base id_role="169"  role="Compliance Specialist"></base>
<base id_role="170"  role="Consumer Loan Specialist"></base>
<base id_role="171"  role="Contract Specialist"></base>
<base id_role="172"  role="Corporate Accountant"></base>
<base id_role="173"  role="Corporate Controller"></base>
<base id_role="174"  role="Cost Accountant"></base>
<base id_role="175"  role="Cost Analyst"></base>
<base id_role="176"  role="Credit And Collections Manager"></base>
<base id_role="177"  role="Credit Specialist"></base>
<base id_role="178"  role="Debt Collector"></base>
<base id_role="179"  role="Director of Accounting"></base>
<base id_role="180"  role="Director of Finance"></base>
<base id_role="181"  role="Escrow Officer"></base>
<base id_role="182"  role="F/I mgr"></base>
<base id_role="183"  role="Finance Analyst"></base>
<base id_role="184"  role="Finance Assistant"></base>
<base id_role="185"  role="Finance Associate"></base>
<base id_role="186"  role="Finance Manager"></base>
<base id_role="187"  role="Financial Accountant"></base>
<base id_role="188"  role="Financial Advisor"></base>
<base id_role="189"  role="Financial Analyst"></base>
<base id_role="190"  role="Financial Consultant"></base>
<base id_role="191"  role="Financial Counselor"></base>
<base id_role="192"  role="Financial Reporting Manager"></base>
<base id_role="193"  role="Financial Representative"></base>
<base id_role="194"  role="Financial Services Representative"></base>
<base id_role="195"  role="Financial Specialist"></base>
<base id_role="196"  role="Fraud Specialist"></base>
<base id_role="197"  role="Full Charge Bookkeeper"></base>
<base id_role="198"  role="Fund Manager"></base>
<base id_role="199"  role="Funding Specialist"></base>
<base id_role="200"  role="General Accountant"></base>
<base id_role="201"  role="General Ledger Accountant"></base>
<base id_role="202"  role="Housing Manager"></base>
<base id_role="203"  role="Insurance Adjuster"></base>
<base id_role="204"  role="Insurance Agent"></base>
<base id_role="205"  role="Insurance Manager"></base>
<base id_role="206"  role="Insurance Sales Representative"></base>
<base id_role="207"  role="Insurance Specialist"></base>
<base id_role="208"  role="Internal Auditor"></base>
<base id_role="209"  role="Investigative Specialist"></base>
<base id_role="210"  role="Investment Advisor"></base>
<base id_role="211"  role="Investment Officer"></base>
<base id_role="212"  role="Junior Accountant"></base>
<base id_role="213"  role="Land Acquisition Manager"></base>
<base id_role="214"  role="Land Developer"></base>
<base id_role="215"  role="Lead Analyst"></base>
<base id_role="216"  role="Leasing Agent"></base>
<base id_role="217"  role="Leasing Consultant"></base>
<base id_role="218"  role="Leasing Manager"></base>
<base id_role="219"  role="Leasing mgr/specialist"></base>
<base id_role="220"  role="Loan Coordinator"></base>
<base id_role="221"  role="Loan Officer"></base>
<base id_role="222"  role="Loan Originator"></base>
<base id_role="223"  role="Loan Processor"></base>
<base id_role="224"  role="Loss Prevention Specialist"></base>
<base id_role="225"  role="Management Accountant"></base>
<base id_role="226"  role="Managing Director"></base>
<base id_role="227"  role="Market Analyst"></base>
<base id_role="228"  role="Merchant"></base>
<base id_role="229"  role="Mortgage Banker"></base>
<base id_role="230"  role="Mortgage Loan Officer"></base>
<base id_role="231"  role="Mortgage Loan Processor"></base>
<base id_role="232"  role="Mortgage Specialist"></base>
<base id_role="233"  role="Mortgage Underwriter"></base>
<base id_role="234"  role="Payroll Accountant"></base>
<base id_role="235"  role="Payroll Administrator"></base>
<base id_role="236"  role="Payroll Analyst"></base>
<base id_role="237"  role="Payroll Clerk"></base>
<base id_role="238"  role="Payroll Manager"></base>
<base id_role="239"  role="Payroll Specialist"></base>
<base id_role="240"  role="Personal Banker"></base>
<base id_role="241"  role="Plant Accountant"></base>
<base id_role="242"  role="Portfolio Manager"></base>
<base id_role="243"  role="Pricing Specialist"></base>
<base id_role="244"  role="Property Accountant"></base>
<base id_role="245"  role="Property Management Coordinator"></base>
<base id_role="246"  role="Purchasing Agent"></base>
<base id_role="247"  role="Quantitative Analyst"></base>
<base id_role="248"  role="Real Estate Agent"></base>
<base id_role="249"  role="Real Estate Analyst"></base>
<base id_role="250"  role="Real Estate Manager"></base>
<base id_role="251"  role="Realtor"></base>
<base id_role="252"  role="Regional Property Manager"></base>
<base id_role="253"  role="Relationship Banker"></base>
<base id_role="254"  role="Reporting Analyst"></base>
<base id_role="255"  role="Researcher"></base>
<base id_role="256"  role="Risk Specialist"></base>
<base id_role="257"  role="Sales Representative"></base>
<base id_role="258"  role="Securities Specialist"></base>
<base id_role="259"  role="Senior Accountant"></base>
<base id_role="260"  role="Senior Accounting Analyst"></base>
<base id_role="261"  role="Senior Accounting Manager"></base>
<base id_role="262"  role="Senior Analyst"></base>
<base id_role="263"  role="Senior Audit Manager"></base>
<base id_role="264"  role="Senior Auditor"></base>
<base id_role="265"  role="Senior Business Analyst"></base>
<base id_role="266"  role="Senior Controller"></base>
<base id_role="267"  role="Senior Corporate Accountant"></base>
<base id_role="268"  role="Senior Credit Analyst"></base>
<base id_role="269"  role="Senior Data Analyst"></base>
<base id_role="270"  role="Senior Financial Accountant"></base>
<base id_role="271"  role="Senior Financial Analyst"></base>
<base id_role="272"  role="Senior Internal Auditor"></base>
<base id_role="273"  role="Senior Staff Accountant"></base>
<base id_role="274"  role="Senior Tax Accountant"></base>
<base id_role="275"  role="Senior Tax Associate"></base>
<base id_role="276"  role="Senior Tax Manager"></base>
<base id_role="277"  role="Senior Underwriter"></base>
<base id_role="278"  role="Showing Agent"></base>
<base id_role="279"  role="Solicitor"></base>
<base id_role="280"  role="Sourcing Manager"></base>
<base id_role="281"  role="Sourcing Specialist"></base>
<base id_role="282"  role="Staff Accountant"></base>
<base id_role="283"  role="Staff Auditor"></base>
<base id_role="284"  role="Statistician"></base>
<base id_role="285"  role="Student Loan Counselor"></base>
<base id_role="286"  role="Tax Accountant"></base>
<base id_role="287"  role="Tax Analyst"></base>
<base id_role="288"  role="Tax Associate"></base>
<base id_role="289"  role="Tax Manager"></base>
<base id_role="290"  role="Tax Preparer"></base>
<base id_role="291"  role="Tax Professional"></base>
<base id_role="292"  role="Tax Specialist"></base>
<base id_role="293"  role="Teller"></base>
<base id_role="294"  role="Title clerk"></base>
<base id_role="295"  role="Transcriptionist"></base>
<base id_role="296"  role="Treasurer"></base>
<base id_role="297"  role="Underwriter"></base>
<base id_role="298"  role="VP of Finance"></base>
<base id_role="299"  role="Baker"></base>
<base id_role="300"  role="Bakery Assistant"></base>
<base id_role="301"  role="Bakery Supervisor"></base>
<base id_role="302"  role="Barista"></base>
<base id_role="303"  role="Bartender/Barback"></base>
<base id_role="304"  role="Breakfast Attendant"></base>
<base id_role="305"  role="Busperson"></base>
<base id_role="306"  role="Butcher"></base>
<base id_role="307"  role="Cake Decorator"></base>
<base id_role="308"  role="Caterer"></base>
<base id_role="309"  role="Chef"></base>
<base id_role="310"  role="Cook"></base>
<base id_role="311"  role="Culinary Manager"></base>
<base id_role="312"  role="Dairy Supervisor"></base>
<base id_role="313"  role="Deli Manager"></base>
<base id_role="314"  role="Dietary Aide"></base>
<base id_role="315"  role="Dietary Technician"></base>
<base id_role="316"  role="Dining Room Manager"></base>
<base id_role="317"  role="Director of Dining Services"></base>
<base id_role="318"  role="Director of Food and Beverage"></base>
<base id_role="319"  role="Dishwasher"></base>
<base id_role="320"  role="Executive Chef"></base>
<base id_role="321"  role="Expeditor"></base>
<base id_role="322"  role="Fast Food Restaurant Assistant Manager"></base>
<base id_role="323"  role="Food and Beverage Manager"></base>
<base id_role="324"  role="Food Preparation Worker"></base>
<base id_role="325"  role="Food Service Worker"></base>
<base id_role="326"  role="Food/Beverage Server"></base>
<base id_role="327"  role="Frozen Supervisor"></base>
<base id_role="328"  role="Grill Cook"></base>
<base id_role="329"  role="Kitchen Assistant"></base>
<base id_role="330"  role="Kitchen Helper"></base>
<base id_role="331"  role="Kitchen Manager"></base>
<base id_role="332"  role="Kitchen Team Member"></base>
<base id_role="333"  role="Kitchen Worker"></base>
<base id_role="334"  role="Lead Cook"></base>
<base id_role="335"  role="Line Cook"></base>
<base id_role="336"  role="Maitre D"></base>
<base id_role="337"  role="Meat Cutter"></base>
<base id_role="338"  role="Meat Supervisor"></base>
<base id_role="339"  role="Pantry Chef"></base>
<base id_role="340"  role="Pastry Cook"></base>
<base id_role="341"  role="Personal Shopper"></base>
<base id_role="342"  role="Pizza Cook"></base>
<base id_role="343"  role="Prep Cook"></base>
<base id_role="344"  role="Prep Person"></base>
<base id_role="345"  role="Replenishment Associate"></base>
<base id_role="346"  role="Restaurant Manager"></base>
<base id_role="347"  role="Restaurant Team Member"></base>
<base id_role="348"  role="Sandwich Maker"></base>
<base id_role="349"  role="Senior Cook"></base>
<base id_role="350"  role="Senior Food Service Worker"></base>
<base id_role="351"  role="Sommelier"></base>
<base id_role="352"  role="Sous Chef"></base>
<base id_role="353"  role="Steward"></base>
<base id_role="354"  role="Abstractor"></base>
<base id_role="355"  role="Activity Coordinator"></base>
<base id_role="356"  role="Acupuncturist"></base>
<base id_role="357"  role="Administrator"></base>
<base id_role="358"  role="Admissions Coordinator"></base>
<base id_role="359"  role="Advanced Practice Nurse"></base>
<base id_role="360"  role="Alcohol Drug Counselor"></base>
<base id_role="361"  role="Allergist"></base>
<base id_role="362"  role="Allergy Technician"></base>
<base id_role="363"  role="Anesthesiologist"></base>
<base id_role="364"  role="Assessor"></base>
<base id_role="365"  role="Audiologist"></base>
<base id_role="366"  role="Behavioral Health Specialist"></base>
<base id_role="367"  role="Behavioral Health Therapist"></base>
<base id_role="368"  role="Biomedical Technician"></base>
<base id_role="369"  role="Biostatistician"></base>
<base id_role="370"  role="Business Office Manager"></base>
<base id_role="371"  role="Cardiologist"></base>
<base id_role="372"  role="Care Coordinator"></base>
<base id_role="373"  role="Care Team Specialist"></base>
<base id_role="374"  role="Caregiver"></base>
<base id_role="375"  role="Case Manager"></base>
<base id_role="376"  role="Certified Medical Technician"></base>
<base id_role="377"  role="Chiropractor"></base>
<base id_role="378"  role="Client/Patient Advocate"></base>
<base id_role="379"  role="Clinic Manager/Staff"></base>
<base id_role="380"  role="Clinical Assistant"></base>
<base id_role="381"  role="Clinical Coordinator"></base>
<base id_role="382"  role="Clinical Director"></base>
<base id_role="383"  role="Clinical Liaison"></base>
<base id_role="384"  role="Clinical Manager"></base>
<base id_role="385"  role="Clinical Nurse Specialist"></base>
<base id_role="386"  role="Clinical Services Manager"></base>
<base id_role="387"  role="CNA"></base>
<base id_role="388"  role="CNO"></base>
<base id_role="389"  role="Coding Specialist"></base>
<base id_role="390"  role="Counselor"></base>
<base id_role="391"  role="CRNA"></base>
<base id_role="392"  role="Dental Assistant"></base>
<base id_role="393"  role="Dental Hygienist"></base>
<base id_role="394"  role="Dentist"></base>
<base id_role="395"  role="Dermatologist"></base>
<base id_role="396"  role="Device Specialist"></base>
<base id_role="397"  role="Dialysis Nurse"></base>
<base id_role="398"  role="Dietician"></base>
<base id_role="399"  role="Direct Support Staff"></base>
<base id_role="400"  role="Dispensary Manager"></base>
<base id_role="401"  role="Document Specialist"></base>
<base id_role="402"  role="Dosimetrist"></base>
<base id_role="403"  role="EEG Technician"></base>
<base id_role="404"  role="Emergency Room Nurse"></base>
<base id_role="405"  role="Emergency Room Technician"></base>
<base id_role="406"  role="EMT"></base>
<base id_role="407"  role="Endocrinologist"></base>
<base id_role="408"  role="Endoscopy Technician"></base>
<base id_role="409"  role="Enrollment Specialist"></base>
<base id_role="410"  role="Facilities"></base>
<base id_role="411"  role="Family Therapist"></base>
<base id_role="412"  role="Float Pool"></base>
<base id_role="413"  role="Gastroenterologist"></base>
<base id_role="414"  role="General Surgeon"></base>
<base id_role="415"  role="Health Information Specialist"></base>
<base id_role="416"  role="Health Technician"></base>
<base id_role="417"  role="Hematologist"></base>
<base id_role="418"  role="Home Health Aide"></base>
<base id_role="419"  role="Home Health Nurse"></base>
<base id_role="420"  role="Hospice Aide"></base>
<base id_role="421"  role="Hospice Nurse"></base>
<base id_role="422"  role="Hospitalist"></base>
<base id_role="423"  role="Infection Prevention Specialist"></base>
<base id_role="424"  role="Intake Specialist"></base>
<base id_role="425"  role="Intensivist"></base>
<base id_role="426"  role="Internal Medicine Physician"></base>
<base id_role="427"  role="Investor Relations"></base>
<base id_role="428"  role="Lab Assistant"></base>
<base id_role="429"  role="Lab Scientist"></base>
<base id_role="430"  role="Lab Supervisor"></base>
<base id_role="431"  role="Lab Tech"></base>
<base id_role="432"  role="Lab Technician"></base>
<base id_role="433"  role="Laboratory Tech"></base>
<base id_role="434"  role="Laboratory Technician"></base>
<base id_role="435"  role="Lactation Assistant"></base>
<base id_role="436"  role="Lactation Consultant"></base>
<base id_role="437"  role="LADC"></base>
<base id_role="438"  role="LCSW"></base>
<base id_role="439"  role="Legal"></base>
<base id_role="440"  role="Legal/Gov Affairs"></base>
<base id_role="441"  role="Licensed Marriage Family Therapist"></base>
<base id_role="442"  role="Licensed Practical Nurse"></base>
<base id_role="443"  role="Licensed Vocational Nurse"></base>
<base id_role="444"  role="LMFT"></base>
<base id_role="445"  role="Logistics"></base>
<base id_role="446"  role="LPN"></base>
<base id_role="447"  role="Mammography Technician"></base>
<base id_role="448"  role="Medical Affairs"></base>
<base id_role="449"  role="Medical Assistant"></base>
<base id_role="450"  role="Medical Coder"></base>
<base id_role="451"  role="Medical Director"></base>
<base id_role="452"  role="Medical Lab Technician"></base>
<base id_role="453"  role="Medical Laboratory Technician"></base>
<base id_role="454"  role="Medical Record Technician"></base>
<base id_role="455"  role="Medical Records Clerk"></base>
<base id_role="456"  role="Medical Secretary"></base>
<base id_role="457"  role="Medical Technician"></base>
<base id_role="458"  role="Medical Technologist"></base>
<base id_role="459"  role="Medicare Specialist"></base>
<base id_role="460"  role="Medication Aide"></base>
<base id_role="461"  role="Mental Health Associate"></base>
<base id_role="462"  role="Mental Health Nurse"></base>
<base id_role="463"  role="Mental Health Specialist"></base>
<base id_role="464"  role="Mental Health Technician"></base>
<base id_role="465"  role="Mental Health Therapist"></base>
<base id_role="466"  role="Microbiologist"></base>
<base id_role="467"  role="Midwife"></base>
<base id_role="468"  role="MLT"></base>
<base id_role="469"  role="MRI Technician"></base>
<base id_role="470"  role="Neonatologist"></base>
<base id_role="471"  role="Neurologist"></base>
<base id_role="472"  role="Neuropsychologist"></base>
<base id_role="473"  role="Nocturnist"></base>
<base id_role="474"  role="Nuclear Medicine Technician"></base>
<base id_role="475"  role="Nuclear Pharmacist"></base>
<base id_role="476"  role="Nurse Aide"></base>
<base id_role="477"  role="Nurse Anesthetist"></base>
<base id_role="478"  role="Nurse Anesthetist/CRNA"></base>
<base id_role="479"  role="Nurse Assistant"></base>
<base id_role="480"  role="Nurse Manager"></base>
<base id_role="481"  role="Nurse Practitioner"></base>
<base id_role="482"  role="Nursing Aide"></base>
<base id_role="483"  role="Nursing Assistant"></base>
<base id_role="484"  role="Nursing Home Administrator"></base>
<base id_role="485"  role="Nutritionist"></base>
<base id_role="486"  role="OB/GYN"></base>
<base id_role="487"  role="Occupational Therapist"></base>
<base id_role="488"  role="Occupational Therapist Assistant"></base>
<base id_role="489"  role="Office Assistant"></base>
<base id_role="490"  role="Operating Room Technician"></base>
<base id_role="491"  role="Ophthalmic Technician"></base>
<base id_role="492"  role="Ophthalmologist / Optometrist"></base>
<base id_role="493"  role="Optician"></base>
<base id_role="494"  role="Oral Surgeon"></base>
<base id_role="495"  role="Orthopedic Surgeon"></base>
<base id_role="496"  role="Orthopedic Technician"></base>
<base id_role="497"  role="Paramedic"></base>
<base id_role="498"  role="Paraprofessional"></base>
<base id_role="499"  role="Pathologist"></base>
<base id_role="500"  role="Pathologist Assistant"></base>
<base id_role="501"  role="Patient Access Specialist"></base>
<base id_role="502"  role="Patient Advocate"></base>
<base id_role="503"  role="Patient Care Coordinator"></base>
<base id_role="504"  role="Patient Care Technician"></base>
<base id_role="505"  role="Patient Service Representative"></base>
<base id_role="506"  role="Pediatric Nurse Practitioner"></base>
<base id_role="507"  role="Pediatrician"></base>
<base id_role="508"  role="Peer Specialist"></base>
<base id_role="509"  role="Perfusionist"></base>
<base id_role="510"  role="Pharmacist"></base>
<base id_role="511"  role="Pharmacy Manager"></base>
<base id_role="512"  role="Pharmacy Resident"></base>
<base id_role="513"  role="Phlebotomist "></base>
<base id_role="514"  role="Phlebotomy Technician"></base>
<base id_role="515"  role="Physical Therapist"></base>
<base id_role="516"  role="Physical Therapist Assistant"></base>
<base id_role="517"  role="Physical Therapy Aide"></base>
<base id_role="518"  role="Physician Assistant"></base>
<base id_role="519"  role="Physiologist"></base>
<base id_role="520"  role="Podiatrist"></base>
<base id_role="521"  role="Polysomnographic Technician"></base>
<base id_role="522"  role="Practice Manager"></base>
<base id_role="523"  role="Psychiatric Technician"></base>
<base id_role="524"  role="Psychiatrist"></base>
<base id_role="525"  role="Psychologist "></base>
<base id_role="526"  role="Public Relations"></base>
<base id_role="527"  role="Pulmonologist"></base>
<base id_role="528"  role="Radiation Oncologist"></base>
<base id_role="529"  role="Radiologic Technician"></base>
<base id_role="530"  role="Radiologist"></base>
<base id_role="531"  role="Radiology Technician"></base>
<base id_role="532"  role="Recovery Specialist"></base>
<base id_role="533"  role="Registered Dietician"></base>
<base id_role="534"  role="Registered Nurse"></base>
<base id_role="535"  role="Rehabilitation Specialist"></base>
<base id_role="536"  role="Reimbursement Specialist"></base>
<base id_role="537"  role="Research Nurse"></base>
<base id_role="538"  role="Research Scientist"></base>
<base id_role="539"  role="Research Technician"></base>
<base id_role="540"  role="Resident Assistant"></base>
<base id_role="541"  role="Respiratory Therapist"></base>
<base id_role="542"  role="Respiratory Therapy Technician"></base>
<base id_role="543"  role="Restorative Aide"></base>
<base id_role="544"  role="Rheumatologist"></base>
<base id_role="545"  role="Screener"></base>
<base id_role="546"  role="Social Services (all)"></base>
<base id_role="547"  role="Social Worker"></base>
<base id_role="548"  role="Sonographer"></base>
<base id_role="549"  role="Speech Pathologist"></base>
<base id_role="550"  role="Sterilization Technician"></base>
<base id_role="551"  role="Surgeon"></base>
<base id_role="552"  role="Surgical Oncologist"></base>
<base id_role="553"  role="Surgical Technician"></base>
<base id_role="554"  role="Teacher"></base>
<base id_role="555"  role="Tech Services (all)"></base>
<base id_role="556"  role="Therapist"></base>
<base id_role="557"  role="Toxicologist"></base>
<base id_role="558"  role="Transition Coordinator"></base>
<base id_role="559"  role="Transport Aide"></base>
<base id_role="560"  role="Trauma Technician"></base>
<base id_role="561"  role="Unit Coord/Mgr"></base>
<base id_role="562"  role="Urogynecologist"></base>
<base id_role="563"  role="Urologist"></base>
<base id_role="564"  role="Appointment Coordinator"></base>
<base id_role="565"  role="Banquet/Catering Crew"></base>
<base id_role="566"  role="Banquet/Catering Manager"></base>
<base id_role="567"  role="Carhop"></base>
<base id_role="568"  role="Concierge"></base>
<base id_role="569"  role="Conference Coordinator"></base>
<base id_role="570"  role="Courtesy Associate"></base>
<base id_role="571"  role="Crew Leader"></base>
<base id_role="572"  role="Day Porter"></base>
<base id_role="573"  role="Dealer"></base>
<base id_role="574"  role="Detailer"></base>
<base id_role="575"  role="Door Attendant"></base>
<base id_role="576"  role="Education Specialist"></base>
<base id_role="577"  role="Entertainer"></base>
<base id_role="578"  role="Fitness Instructor"></base>
<base id_role="579"  role="Floor Supervisor"></base>
<base id_role="580"  role="Floor Technician"></base>
<base id_role="581"  role="Front Desk Agent"></base>
<base id_role="582"  role="Front Desk Manager"></base>
<base id_role="583"  role="Front End Associate"></base>
<base id_role="584"  role="Front End Manager"></base>
<base id_role="585"  role="Front Office Manager"></base>
<base id_role="586"  role="Golf Professional"></base>
<base id_role="587"  role="Greeter"></base>
<base id_role="588"  role="Group Manager"></base>
<base id_role="589"  role="Guest Service Agent"></base>
<base id_role="590"  role="Hotel Bell Person"></base>
<base id_role="591"  role="Hotel Manager"></base>
<base id_role="592"  role="House Attendant"></base>
<base id_role="593"  role="House Manager"></base>
<base id_role="594"  role="Housekeeper"></base>
<base id_role="595"  role="Housekeeping Manager"></base>
<base id_role="596"  role="Laundry Attendant"></base>
<base id_role="597"  role="Laundry Supervisor"></base>
<base id_role="598"  role="Locker Room Attendant"></base>
<base id_role="599"  role="Lot attendant"></base>
<base id_role="600"  role="Lounge Manager"></base>
<base id_role="601"  role="Manager in Training"></base>
<base id_role="602"  role="Manager Trainee"></base>
<base id_role="603"  role="Massage Therapist"></base>
<base id_role="604"  role="Member Services Representative"></base>
<base id_role="605"  role="Nail Technician"></base>
<base id_role="606"  role="Night Auditor"></base>
<base id_role="607"  role="Night Manager"></base>
<base id_role="608"  role="Night Supervisor"></base>
<base id_role="609"  role="Parking Attendant"></base>
<base id_role="610"  role="Planner"></base>
<base id_role="611"  role="Pool Attendant"></base>
<base id_role="612"  role="Pool Manager"></base>
<base id_role="613"  role="Porter"></base>
<base id_role="614"  role="Production Associate"></base>
<base id_role="615"  role="Professional Driver"></base>
<base id_role="616"  role="Program Aide"></base>
<base id_role="617"  role="Program Assistant"></base>
<base id_role="618"  role="Program Coordinator"></base>
<base id_role="619"  role="Public Area Attendant"></base>
<base id_role="620"  role="Room Attendant"></base>
<base id_role="621"  role="Route Driver"></base>
<base id_role="622"  role="Senior Housekeeper"></base>
<base id_role="623"  role="Service Associate"></base>
<base id_role="624"  role="Shuttle Driver"></base>
<base id_role="625"  role="Spa Associate"></base>
<base id_role="626"  role="Spa Manager"></base>
<base id_role="627"  role="Spa Therapist"></base>
<base id_role="628"  role="Support Specialist"></base>
<base id_role="629"  role="Tennis Instructor"></base>
<base id_role="630"  role="Turndown Attendant"></base>
<base id_role="631"  role="Valet"></base>
<base id_role="632"  role="Van Driver"></base>
<base id_role="633"  role="Benefit Specialist"></base>
<base id_role="634"  role="Benefits Specialist"></base>
<base id_role="635"  role="Business Process Analyst"></base>
<base id_role="636"  role="Campus Recruiter"></base>
<base id_role="637"  role="Change Management Specialist"></base>
<base id_role="638"  role="CHRO"></base>
<base id_role="639"  role="Communications Specialist"></base>
<base id_role="640"  role="Compensation Specialist"></base>
<base id_role="641"  role="Corporate Recruiter"></base>
<base id_role="642"  role="Dir Total Rewards"></base>
<base id_role="643"  role="Employee Relations Manager"></base>
<base id_role="644"  role="Employment Specialist"></base>
<base id_role="645"  role="HR Manager"></base>
<base id_role="646"  role="HR Representative"></base>
<base id_role="647"  role="HR Specialist"></base>
<base id_role="648"  role="HRIS Specialist"></base>
<base id_role="649"  role="Information Security Specialist"></base>
<base id_role="650"  role="Learning and Development Manager"></base>
<base id_role="651"  role="Learning and Development Manager"></base>
<base id_role="652"  role="Onboarding Specialist"></base>
<base id_role="653"  role="Pharmacy Technician"></base>
<base id_role="654"  role="Recruiter"></base>
<base id_role="655"  role="Recruiting Manager"></base>
<base id_role="656"  role="Recruiting Specialist"></base>
<base id_role="657"  role="Senior Benefits Analyst"></base>
<base id_role="658"  role="Senior Compensation Analyst"></base>
<base id_role="659"  role="Service Center Manager"></base>
<base id_role="660"  role="Staffing Coordinator"></base>
<base id_role="661"  role="Staffing Specialist"></base>
<base id_role="662"  role="Talent Management Specialist"></base>
<base id_role="663"  role="Total Rewards Manager"></base>
<base id_role="664"  role="Trainer"></base>
<base id_role="665"  role="Training Manager"></base>
<base id_role="666"  role="VP HR"></base>
<base id_role="667"  role="Wellness Consultant"></base>
<base id_role="668"  role="Workforce Planning Specialist"></base>
<base id_role="669"  role="Analytics Specialist"></base>
<base id_role="670"  role="Application Architect"></base>
<base id_role="671"  role="Application Manager"></base>
<base id_role="672"  role="Application Software Developer"></base>
<base id_role="673"  role="Application Specialist"></base>
<base id_role="674"  role="Back End Developer"></base>
<base id_role="675"  role="Business Analyst"></base>
<base id_role="676"  role="Business Continuity Specialist"></base>
<base id_role="677"  role="Business Intelligence Developer"></base>
<base id_role="678"  role="Chief Information Officer"></base>
<base id_role="679"  role="Chief Security Officer"></base>
<base id_role="680"  role="Cloud Architect"></base>
<base id_role="681"  role="Cloud Developer"></base>
<base id_role="682"  role="Computer Operator"></base>
<base id_role="683"  role="CTO"></base>
<base id_role="684"  role="Curriculum Designer"></base>
<base id_role="685"  role="Data Administrator"></base>
<base id_role="686"  role="Data Analyst"></base>
<base id_role="687"  role="Data Architect"></base>
<base id_role="688"  role="Data Center Manager"></base>
<base id_role="689"  role="Data Consultant"></base>
<base id_role="690"  role="Data Engineer"></base>
<base id_role="691"  role="Data Entry Operator"></base>
<base id_role="692"  role="Data Scientist"></base>
<base id_role="693"  role="Data Specialist"></base>
<base id_role="694"  role="Database Developer"></base>
<base id_role="695"  role="DBA"></base>
<base id_role="696"  role="Desktop Support"></base>
<base id_role="697"  role="Developer"></base>
<base id_role="698"  role="DevOps Specialist"></base>
<base id_role="699"  role="Embedded Software Engineer"></base>
<base id_role="700"  role="Front End Developer"></base>
<base id_role="701"  role="Full Stack Developer"></base>
<base id_role="702"  role="Help Desk Manager"></base>
<base id_role="703"  role="Help Desk Specialist"></base>
<base id_role="704"  role="Incident Responder"></base>
<base id_role="705"  role="Information Technology Manager"></base>
<base id_role="706"  role="IT Auditor"></base>
<base id_role="707"  role="IT Manager"></base>
<base id_role="708"  role="Level 2 Support"></base>
<base id_role="709"  role="Linux Administrator"></base>
<base id_role="710"  role="Managing Partner"></base>
<base id_role="711"  role="Mobile Developer"></base>
<base id_role="712"  role="Network Administrator"></base>
<base id_role="713"  role="Network Analyst"></base>
<base id_role="714"  role="Network Architect"></base>
<base id_role="715"  role="Network Engineer"></base>
<base id_role="716"  role="Network Manager"></base>
<base id_role="717"  role="Network Security Analyst"></base>
<base id_role="718"  role="Network Security Specialist"></base>
<base id_role="719"  role="Principal Consultant"></base>
<base id_role="720"  role="Sales"></base>
<base id_role="721"  role="SAP Specialist"></base>
<base id_role="722"  role="Security Architect"></base>
<base id_role="723"  role="Security Developer"></base>
<base id_role="724"  role="Security Engineer"></base>
<base id_role="725"  role="Senior Consultant"></base>
<base id_role="726"  role="Software Administrator"></base>
<base id_role="727"  role="Software Architect"></base>
<base id_role="728"  role="Software Consultant"></base>
<base id_role="729"  role="Software Developer"></base>
<base id_role="730"  role="Software Engineer"></base>
<base id_role="731"  role="Software Technician"></base>
<base id_role="732"  role="Storage Administrator"></base>
<base id_role="733"  role="System Administrator"></base>
<base id_role="734"  role="Systems Analyst"></base>
<base id_role="735"  role="Systems Architect"></base>
<base id_role="736"  role="Systems Consultant"></base>
<base id_role="737"  role="Systems Developer"></base>
<base id_role="738"  role="Systems Engineer"></base>
<base id_role="739"  role="Systems Specialist"></base>
<base id_role="740"  role="Systems Technician"></base>
<base id_role="741"  role="Technical Services"></base>
<base id_role="742"  role="Technical Support"></base>
<base id_role="743"  role="Testing Specialist"></base>
<base id_role="744"  role="UI Designer"></base>
<base id_role="745"  role="UX/Web Designer"></base>
<base id_role="746"  role="Web Designer"></base>
<base id_role="747"  role="Assembler"></base>
<base id_role="748"  role="Assembly Line Worker"></base>
<base id_role="749"  role="Boiler Operator"></base>
<base id_role="750"  role="Brewer"></base>
<base id_role="751"  role="Civil Engineer"></base>
<base id_role="752"  role="CNC Machinist"></base>
<base id_role="753"  role="CNC Operator"></base>
<base id_role="754"  role="Controls Engineer"></base>
<base id_role="755"  role="COO"></base>
<base id_role="756"  role="Cultivation Staff"></base>
<base id_role="757"  role="Design Engineer"></base>
<base id_role="758"  role="Dismantler"></base>
<base id_role="759"  role="Electronic Assembler"></base>
<base id_role="760"  role="Engineer"></base>
<base id_role="761"  role="Estimator"></base>
<base id_role="762"  role="Fabricator"></base>
<base id_role="763"  role="Factory Worker"></base>
<base id_role="764"  role="Farm Manager"></base>
<base id_role="765"  role="Field Engineer"></base>
<base id_role="766"  role="Field Service Technician"></base>
<base id_role="767"  role="Foreman"></base>
<base id_role="768"  role="General Laborer"></base>
<base id_role="769"  role="Grower"></base>
<base id_role="770"  role="Industrial Engineer"></base>
<base id_role="771"  role="Inspector"></base>
<base id_role="772"  role="Laborer"></base>
<base id_role="773"  role="Line Operator"></base>
<base id_role="774"  role="Line Worker"></base>
<base id_role="775"  role="Machine Helper"></base>
<base id_role="776"  role="Machine Operator"></base>
<base id_role="777"  role="Machinist"></base>
<base id_role="778"  role="Manufacturing Engineer"></base>
<base id_role="779"  role="Manufacturing Process Engineer"></base>
<base id_role="780"  role="Manufacturing Production Manager"></base>
<base id_role="781"  role="Manufacturing Technician"></base>
<base id_role="782"  role="Manufacturing Worker"></base>
<base id_role="783"  role="Materials Handler"></base>
<base id_role="784"  role="Materials Manager"></base>
<base id_role="785"  role="Mechanical Designer"></base>
<base id_role="786"  role="Mechanical Engineer"></base>
<base id_role="787"  role="Operations Analyst"></base>
<base id_role="788"  role="Operations Assistant"></base>
<base id_role="789"  role="Operations Associate"></base>
<base id_role="790"  role="Operations Consultant"></base>
<base id_role="791"  role="Operations Coordinator"></base>
<base id_role="792"  role="Operations Manager"></base>
<base id_role="793"  role="Operations Representative"></base>
<base id_role="794"  role="Operations Specialist"></base>
<base id_role="795"  role="Operations Supervisor"></base>
<base id_role="796"  role="Packaging Engineer"></base>
<base id_role="797"  role="Parts Manager"></base>
<base id_role="798"  role="Performance Engineer"></base>
<base id_role="799"  role="Plant Manager"></base>
<base id_role="800"  role="Plant Operator"></base>
<base id_role="801"  role="Power Plant Operator"></base>
<base id_role="802"  role="Precision Assembler"></base>
<base id_role="803"  role="Press Operator"></base>
<base id_role="804"  role="Process Engineer"></base>
<base id_role="805"  role="Process Operator"></base>
<base id_role="806"  role="Processing Staff"></base>
<base id_role="807"  role="Production Control Clerk"></base>
<base id_role="808"  role="Production Control Manager"></base>
<base id_role="809"  role="Production Coordinator"></base>
<base id_role="810"  role="Production Foreman"></base>
<base id_role="811"  role="Production Manager"></base>
<base id_role="812"  role="Production Planner/Scheduler"></base>
<base id_role="813"  role="QA Manager"></base>
<base id_role="814"  role="QA Specialist"></base>
<base id_role="815"  role="Quality Engineer"></base>
<base id_role="816"  role="Reliability Engineer"></base>
<base id_role="817"  role="Robot Programmer"></base>
<base id_role="818"  role="Safety Manager"></base>
<base id_role="819"  role="Scheduler"></base>
<base id_role="820"  role="Site Manager"></base>
<base id_role="821"  role="Structural Assembler"></base>
<base id_role="822"  role="Superintendent"></base>
<base id_role="823"  role="Test Engineer"></base>
<base id_role="824"  role="Validation Engineer"></base>
<base id_role="825"  role="VP Operations"></base>
<base id_role="826"  role="Advertising Manager"></base>
<base id_role="827"  role="Ambassador"></base>
<base id_role="828"  role="Artist"></base>
<base id_role="829"  role="Brand Manager"></base>
<base id_role="830"  role="Brand Specialist"></base>
<base id_role="831"  role="Category Manager"></base>
<base id_role="832"  role="Community Relations Manager"></base>
<base id_role="833"  role="Content Manager"></base>
<base id_role="834"  role="Content Specialist"></base>
<base id_role="835"  role="Copywriter"></base>
<base id_role="836"  role="Creative Director"></base>
<base id_role="837"  role="Design Specialist"></base>
<base id_role="838"  role="Digital Asset Specialist"></base>
<base id_role="839"  role="Digital Marketing Manager"></base>
<base id_role="840"  role="Digital Marketing Specialist"></base>
<base id_role="841"  role="Graphic Artist"></base>
<base id_role="842"  role="Graphic Designer"></base>
<base id_role="843"  role="Industrial Designer"></base>
<base id_role="844"  role="Integrated Marketing Manager"></base>
<base id_role="845"  role="Interior Designer"></base>
<base id_role="846"  role="Marketing Analyst"></base>
<base id_role="847"  role="Marketing Assistant"></base>
<base id_role="848"  role="Marketing Associate"></base>
<base id_role="849"  role="Marketing Consultant"></base>
<base id_role="850"  role="Marketing Coordinator"></base>
<base id_role="851"  role="Marketing Director"></base>
<base id_role="852"  role="Marketing Intern"></base>
<base id_role="853"  role="Marketing Manager"></base>
<base id_role="854"  role="Media Manager"></base>
<base id_role="855"  role="Media Specialist"></base>
<base id_role="856"  role="Model"></base>
<base id_role="857"  role="Photographer"></base>
<base id_role="858"  role="Promotions Specialist"></base>
<base id_role="859"  role="Proofreader"></base>
<base id_role="860"  role="SEO Specialist"></base>
<base id_role="861"  role="Social Media Manager"></base>
<base id_role="862"  role="Social Media Specialist"></base>
<base id_role="863"  role="Story Teller"></base>
<base id_role="864"  role="Visual Designer"></base>
<base id_role="865"  role="VP Marketing"></base>
<base id_role="866"  role="Web Content Manager"></base>
<base id_role="867"  role="Buyer"></base>
<base id_role="868"  role="Merchandizer"></base>
<base id_role="869"  role="Product Manager"></base>
<base id_role="870"  role="Visual Merchandiser"></base>
<base id_role="871"  role="Apparel Designer"></base>
<base id_role="872"  role="Apparel Sales Associate"></base>
<base id_role="873"  role="Asset Protection Specialist"></base>
<base id_role="874"  role="Bagger"></base>
<base id_role="875"  role="Beauty Consultant"></base>
<base id_role="876"  role="Bookseller"></base>
<base id_role="877"  role="Boutique Manager"></base>
<base id_role="878"  role="Bridal Sales Representative"></base>
<base id_role="879"  role="Cashier"></base>
<base id_role="880"  role="Cashier Supervisor"></base>
<base id_role="881"  role="Channel Manager"></base>
<base id_role="882"  role="Concessionist"></base>
<base id_role="883"  role="Convenience Store Clerk"></base>
<base id_role="884"  role="Counter Help"></base>
<base id_role="885"  role="Counterperson"></base>
<base id_role="886"  role="Demonstrator"></base>
<base id_role="887"  role="Esthetician"></base>
<base id_role="888"  role="Eyewear Consultant"></base>
<base id_role="889"  role="Fashion Consultant"></base>
<base id_role="890"  role="Fashion Designer"></base>
<base id_role="891"  role="Floor Associate"></base>
<base id_role="892"  role="Floor Manager"></base>
<base id_role="893"  role="Florist"></base>
<base id_role="894"  role="Gift Wrapper"></base>
<base id_role="895"  role="Grocery Manager"></base>
<base id_role="896"  role="Grocery Stocker/Clerk"></base>
<base id_role="897"  role="Hair Stylist"></base>
<base id_role="898"  role="Jewelry Consultant"></base>
<base id_role="899"  role="Jewelry Sales Associate"></base>
<base id_role="900"  role="Keyholder"></base>
<base id_role="901"  role="Loss Prevention Agent"></base>
<base id_role="902"  role="Luxury Sales Associate"></base>
<base id_role="903"  role="Mall Manager"></base>
<base id_role="904"  role="Malll Manager"></base>
<base id_role="905"  role="Manicurist"></base>
<base id_role="906"  role="Meat Associate"></base>
<base id_role="907"  role="Meat Clerk"></base>
<base id_role="908"  role="Merchandise Handler"></base>
<base id_role="909"  role="Optical Stylist"></base>
<base id_role="910"  role="Party Planner"></base>
<base id_role="911"  role="Produce Associate"></base>
<base id_role="912"  role="Produce Clerk"></base>
<base id_role="913"  role="Produce Supervisor"></base>
<base id_role="914"  role="Retail Associate"></base>
<base id_role="915"  role="Retail Manager"></base>
<base id_role="916"  role="Service Specialist"></base>
<base id_role="917"  role="Shop Assistant"></base>
<base id_role="918"  role="Shopper"></base>
<base id_role="919"  role="Snack Bar Attendant"></base>
<base id_role="920"  role="Stocker"></base>
<base id_role="921"  role="Store Clerk"></base>
<base id_role="922"  role="Store Manager"></base>
<base id_role="923"  role="Tire Changer"></base>
<base id_role="924"  role="Wedding Planner"></base>
<base id_role="925"  role="Wedding Specialist"></base>
<base id_role="926"  role="Account Manager"></base>
<base id_role="927"  role="Development Manager"></base>
<base id_role="928"  role="Digital Sales Manager"></base>
<base id_role="929"  role="Digital Sales Specialist"></base>
<base id_role="930"  role="Ecommerce Manager"></base>
<base id_role="931"  role="Ecommerce Specialist"></base>
<base id_role="932"  role="Energy Advisor"></base>
<base id_role="933"  role="Energy Auditor"></base>
<base id_role="934"  role="Energy Consultant"></base>
<base id_role="935"  role="Field Sales Representative"></base>
<base id_role="936"  role="Inside Sales Representative"></base>
<base id_role="937"  role="Internet Sales Agent"></base>
<base id_role="938"  role="Nat/Reg/Key Account Mgr"></base>
<base id_role="939"  role="National Account Manager"></base>
<base id_role="940"  role="Outside Sales Representative"></base>
<base id_role="941"  role="Product Specialist"></base>
<base id_role="942"  role="Product Trainer"></base>
<base id_role="943"  role="Regional Account Manager"></base>
<base id_role="944"  role="Regional Sales Manager"></base>
<base id_role="945"  role="Shoe Salesperson"></base>
<base id_role="946"  role="Solar Sales Specialist"></base>
<base id_role="947"  role="Territory Manager"></base>
<base id_role="948"  role="VP Sales"></base>
<base id_role="949"  role="Security Analyst"></base>
<base id_role="950"  role="Security Consultant"></base>
<base id_role="951"  role="Security Director"></base>
<base id_role="952"  role="Security Guard"></base>
<base id_role="953"  role="Security Manager"></base>
<base id_role="954"  role="Security Officer"></base>
<base id_role="955"  role="Security Specialist"></base>
<base id_role="956"  role="Appliance Technician"></base>
<base id_role="957"  role="Apprentice Carpenter"></base>
<base id_role="958"  role="Apprentice Electrician"></base>
<base id_role="959"  role="Apprentice Machinist"></base>
<base id_role="960"  role="Apprentice Painter"></base>
<base id_role="961"  role="Apprentice Plumber"></base>
<base id_role="962"  role="Auto Mechanic"></base>
<base id_role="963"  role="Boilermaker"></base>
<base id_role="964"  role="Bricklayer"></base>
<base id_role="965"  role="Cabinet Maker"></base>
<base id_role="966"  role="Carpenter"></base>
<base id_role="967"  role="Carpenter Assistant"></base>
<base id_role="968"  role="Carpenter Helper"></base>
<base id_role="969"  role="Concrete Finisher"></base>
<base id_role="970"  role="Crane Operator"></base>
<base id_role="971"  role="Diesel Technician"></base>
<base id_role="972"  role="Electrician"></base>
<base id_role="973"  role="Electrician Helper"></base>
<base id_role="974"  role="Electronic Technician"></base>
<base id_role="975"  role="Elevator Mechanic"></base>
<base id_role="976"  role="Elevator Technician"></base>
<base id_role="977"  role="Equipment Operator"></base>
<base id_role="978"  role="Fence Installer"></base>
<base id_role="979"  role="Fleet Mechanic"></base>
<base id_role="980"  role="Framing Carpenter"></base>
<base id_role="981"  role="Grinder"></base>
<base id_role="982"  role="Handyman"></base>
<base id_role="983"  role="HVAC Technician"></base>
<base id_role="984"  role="Journeyman Carpenter"></base>
<base id_role="985"  role="Journeyman Electrician"></base>
<base id_role="986"  role="Journeyman Painter"></base>
<base id_role="987"  role="Journeyman Pipefitter"></base>
<base id_role="988"  role="Journeyman Plumber"></base>
<base id_role="989"  role="Journeyman Roofer"></base>
<base id_role="990"  role="Journeyman Welder"></base>
<base id_role="991"  role="Lineman"></base>
<base id_role="992"  role="Locksmith"></base>
<base id_role="993"  role="Mason"></base>
<base id_role="994"  role="Master Electrician"></base>
<base id_role="995"  role="Master HVAC Technician"></base>
<base id_role="996"  role="Master Mechanic"></base>
<base id_role="997"  role="Master Plumber"></base>
<base id_role="998"  role="Master Scheduler"></base>
<base id_role="999"  role="Master Technician"></base>
<base id_role="1000"  role="Material Handler"></base>
<base id_role="1001"  role="Mechanic"></base>
<base id_role="1002"  role="Mechanical Technician"></base>
<base id_role="1003"  role="Metal Worker"></base>
<base id_role="1004"  role="Millwright"></base>
<base id_role="1005"  role="Painter"></base>
<base id_role="1006"  role="Painter Helper"></base>
<base id_role="1007"  role="Pattern Maker"></base>
<base id_role="1008"  role="Pipe Fitter"></base>
<base id_role="1009"  role="Pipefitter"></base>
<base id_role="1010"  role="Plumber"></base>
<base id_role="1011"  role="Plumber Helper"></base>
<base id_role="1012"  role="Rigger"></base>
<base id_role="1013"  role="Roofer"></base>
<base id_role="1014"  role="Service Mechanic"></base>
<base id_role="1015"  role="Site Surveyor"></base>
<base id_role="1016"  role="Solar Installation Specialist"></base>
<base id_role="1017"  role="Surveyor"></base>
<base id_role="1018"  role="Tool And Die Maker"></base>
<base id_role="1019"  role="Welder"></base>
<base id_role="1020"  role="Bus Driver"></base>
<base id_role="1021"  role="Cab Driver"></base>
<base id_role="1022"  role="Chauffeur"></base>
<base id_role="1023"  role="Conductor"></base>
<base id_role="1024"  role="Courier"></base>
<base id_role="1025"  role="Deckhand"></base>
<base id_role="1026"  role="Delivery Driver"></base>
<base id_role="1027"  role="Dispatcher"></base>
<base id_role="1028"  role="Distribution Associate"></base>
<base id_role="1029"  role="Distribution Manager"></base>
<base id_role="1030"  role="Fleet Manager"></base>
<base id_role="1031"  role="Fulfillment Associate"></base>
<base id_role="1032"  role="Inventory Clerk"></base>
<base id_role="1033"  role="Inventory Control Analyst"></base>
<base id_role="1034"  role="Inventory Control Clerk"></base>
<base id_role="1035"  role="Inventory Control Manager"></base>
<base id_role="1036"  role="Inventory Control Specialist"></base>
<base id_role="1037"  role="Operator"></base>
<base id_role="1038"  role="Order Picker/Selector"></base>
<base id_role="1039"  role="Packaging Operator"></base>
<base id_role="1040"  role="Receiving Clerk"></base>
<base id_role="1041"  role="Shipping And Receiving Clerk"></base>
<base id_role="1042"  role="Shipping And Receiving Manager"></base>
<base id_role="1043"  role="Supply Chain Coordinator"></base>
<base id_role="1044"  role="Supply Chain Manager"></base>
<base id_role="1045"  role="Taxi Driver"></base>
<base id_role="1046"  role="Traffic Manager"></base>
<base id_role="1047"  role="Transportation Manager"></base>
<base id_role="1048"  role="Transportation Planner"></base>
<base id_role="1049"  role="Truck Driver"></base>
<base id_role="1050"  role="Warehouse Manager"></base>
<base id_role="1051"  role="Warehouse Worker"></base>
<base id_role="1052"  role="Acquisition Specialist"></base>
<base id_role="1053"  role="Captain"></base>
<base id_role="1054"  role="Coach"></base>
<base id_role="1055"  role="Collector"></base>
<base id_role="1056"  role="Crew Member"></base>
<base id_role="1057"  role="Delivery Specialist"></base>
<base id_role="1058"  role="Designer"></base>
<base id_role="1059"  role="EXCLUDE"></base>
<base id_role="1060"  role="Executive Director"></base>
<base id_role="1061"  role="General Manager"></base>
<base id_role="1062"  role="Helper"></base>
<base id_role="1063"  role="Instructor"></base>
<base id_role="1064"  role="Interpreter"></base>
<base id_role="1065"  role="Interviewer"></base>
<base id_role="1066"  role="Investigator"></base>
<base id_role="1067"  role="Management Analyst"></base>
<base id_role="1068"  role="Management Intern"></base>
<base id_role="1069"  role="Management Trainee"></base>
<base id_role="1070"  role="Manager"></base>
<base id_role="1071"  role="Marketing"></base>
<base id_role="1072"  role="Office Manager"></base>
<base id_role="1073"  role="Processing"></base>
<base id_role="1074"  role="Production"></base>
<base id_role="1075"  role="Professional Services"></base>
<base id_role="1076"  role="Program Manager"></base>
<base id_role="1077"  role="Project Accountant"></base>
<base id_role="1078"  role="Project Assistant"></base>
<base id_role="1079"  role="Project Coordinator"></base>
<base id_role="1080"  role="Project Manager"></base>
<base id_role="1081"  role="Region Manager"></base>
<base id_role="1082"  role="Regulatory Affairs/Reporting Specialist"></base>
<base id_role="1083"  role="Shift Manager"></base>
<base id_role="1084"  role="Strategist"></base>
<base id_role="1085"  role="Team Member"></base>
<base id_role="1086"  role="Vice president"></base>
<base id_role="1087"  role="Service Center Specialist"></base>
<base id_role="1088"  role="VIP Services Representative"></base>
<base id_role="1089"  role="Athletics Coordinator"></base>
<base id_role="1090"  role="Audiovisual Technician"></base>
<base id_role="1091"  role="Booking Assistant"></base>
<base id_role="1092"  role="Choreographer"></base>
<base id_role="1093"  role="Clearance Specialist"></base>
<base id_role="1094"  role="Clubhouse Manager"></base>
<base id_role="1095"  role="Concession Manager"></base>
<base id_role="1096"  role="Curation Specialist"></base>
<base id_role="1097"  role="Docent"></base>
<base id_role="1098"  role="Draper"></base>
<base id_role="1099"  role="Emcee"></base>
<base id_role="1100"  role="Executive Producer"></base>
<base id_role="1101"  role="Fundraising Assistant"></base>
<base id_role="1102"  role="Fundraising Coordinator"></base>
<base id_role="1103"  role="Fundraising Manager"></base>
<base id_role="1104"  role="Gallery Manager"></base>
<base id_role="1105"  role="Game Attendant"></base>
<base id_role="1106"  role="Golf Attendant"></base>
<base id_role="1107"  role="Golf Pro"></base>
<base id_role="1108"  role="Golf Ranger"></base>
<base id_role="1109"  role="Golf Shop Attendant"></base>
<base id_role="1110"  role="Golf Starter"></base>
<base id_role="1111"  role="Greenskeeper"></base>
<base id_role="1112"  role="Museum Director"></base>
<base id_role="1113"  role="Museum Specialist"></base>
<base id_role="1114"  role="Music Director"></base>
<base id_role="1115"  role="Music Engineer"></base>
<base id_role="1116"  role="On-Air Talent"></base>
<base id_role="1117"  role="Players Club Representative"></base>
<base id_role="1118"  role="Preparator"></base>
<base id_role="1119"  role="Presenter"></base>
<base id_role="1120"  role="Projectionist"></base>
<base id_role="1121"  role="Publicist"></base>
<base id_role="1122"  role="Set Designer/Mgr"></base>
<base id_role="1123"  role="Show Coordinator"></base>
<base id_role="1124"  role="Show Runner"></base>
<base id_role="1125"  role="Sound Technician"></base>
<base id_role="1126"  role="Special Effects Specialist"></base>
<base id_role="1127"  role="Sponsorship Manager"></base>
<base id_role="1128"  role="Stage Crew"></base>
<base id_role="1129"  role="Talent Buyer"></base>
<base id_role="1130"  role="Talent Scout"></base>
<base id_role="1131"  role="Television Executive"></base>
<base id_role="1132"  role="Theater Manager"></base>
<base id_role="1133"  role="Ticket Taker"></base>
<base id_role="1134"  role="Ticket Trader"></base>
<base id_role="1135"  role="Ticketing Manager"></base>
<base id_role="1136"  role="Tour Manager"></base>
<base id_role="1137"  role="Trip Leader"></base>
<base id_role="1138"  role="Vocalist"></base>
<base id_role="1139"  role="Waterfront Coordinator"></base>
<base id_role="1140"  role="Director of Facilities"></base>
<base id_role="1141"  role="Gutter Cleaner"></base>
<base id_role="1142"  role="Industrial Cleaner"></base>
<base id_role="1143"  role="Permit Coordinator"></base>
<base id_role="1144"  role="Bank Operations Specialist"></base>
<base id_role="1145"  role="Budget Analyst"></base>
<base id_role="1146"  role="CFP"></base>
<base id_role="1147"  role="Collateral Specialist"></base>
<base id_role="1148"  role="Electronic Banking Specialist"></base>
<base id_role="1149"  role="Finance Coordinator"></base>
<base id_role="1150"  role="Financial Planner"></base>
<base id_role="1151"  role="Fiscal Technician"></base>
<base id_role="1152"  role="Fixed Income Specialist"></base>
<base id_role="1153"  role="Forecasting Specialist"></base>
<base id_role="1154"  role="Fraud Prevention Specialist"></base>
<base id_role="1155"  role="Freight Broker"></base>
<base id_role="1156"  role="Fund Accountant"></base>
<base id_role="1157"  role="Housing Consultant"></base>
<base id_role="1158"  role="Insurance Sales Manager"></base>
<base id_role="1159"  role="Investment Analyst"></base>
<base id_role="1160"  role="Investment Banking Analyst"></base>
<base id_role="1161"  role="Investment Banking Associate"></base>
<base id_role="1162"  role="Investor Relations Manager"></base>
<base id_role="1163"  role="Land Analyst"></base>
<base id_role="1164"  role="Land Manager"></base>
<base id_role="1165"  role="Lease Administrator"></base>
<base id_role="1166"  role="Mortgage Assistant"></base>
<base id_role="1167"  role="Mortgage Broker"></base>
<base id_role="1168"  role="Mortgage Inspector"></base>
<base id_role="1169"  role="Payment Manager"></base>
<base id_role="1170"  role="Portfolio Analyst"></base>
<base id_role="1171"  role="Property Disposal Specialist"></base>
<base id_role="1172"  role="Property Inspector"></base>
<base id_role="1173"  role="Real Estate Developer"></base>
<base id_role="1174"  role="Real Estate Photographer"></base>
<base id_role="1175"  role="Real Estate Sales Representative"></base>
<base id_role="1176"  role="Residential Property Manager"></base>
<base id_role="1177"  role="Revenue Accountant"></base>
<base id_role="1178"  role="Securities Broker"></base>
<base id_role="1179"  role="Senior Accounting Clerk"></base>
<base id_role="1180"  role="Senior Cost Accountant"></base>
<base id_role="1181"  role="Senior Fund Accountant"></base>
<base id_role="1182"  role="Senior Reporting Analyst"></base>
<base id_role="1183"  role="Senior Revenue Accountant"></base>
<base id_role="1184"  role="Settlement Specialist"></base>
<base id_role="1185"  role="Tax Examiner"></base>
<base id_role="1186"  role="Telesales Representative"></base>
<base id_role="1187"  role="Trader"></base>
<base id_role="1188"  role="VP Finance"></base>
<base id_role="1189"  role="Wealth Advisor"></base>
<base id_role="1190"  role="Admitting Clerk"></base>
<base id_role="1191"  role="Anesthesia Technologist"></base>
<base id_role="1192"  role="Audiology Technician"></base>
<base id_role="1193"  role="Clinical Services Coordinator"></base>
<base id_role="1194"  role="Credentialing Coordinator"></base>
<base id_role="1195"  role="Crisis Clinician"></base>
<base id_role="1196"  role="Dialysis Technician"></base>
<base id_role="1197"  role="ECG / EKG Technologist"></base>
<base id_role="1198"  role="EKG Technician"></base>
<base id_role="1199"  role="Epidemiologist"></base>
<base id_role="1200"  role="General Practitioner"></base>
<base id_role="1201"  role="Geriatrician"></base>
<base id_role="1202"  role="Government Affairs"></base>
<base id_role="1203"  role="Head Nurse"></base>
<base id_role="1204"  role="Hemodialysis Technician"></base>
<base id_role="1205"  role="Hepatologist"></base>
<base id_role="1206"  role="Histology Technician"></base>
<base id_role="1207"  role="Hospital Technician"></base>
<base id_role="1208"  role="Medical Writer"></base>
<base id_role="1209"  role="Mental Health Practitioner"></base>
<base id_role="1210"  role="Nephrologists"></base>
<base id_role="1211"  role="Neurosurgeon"></base>
<base id_role="1212"  role="Nurse Clinician"></base>
<base id_role="1213"  role="Operating Room Manager"></base>
<base id_role="1214"  role="Ophthalmic Assistant"></base>
<base id_role="1215"  role="Ophthalmology Technician"></base>
<base id_role="1216"  role="Optometry Technician"></base>
<base id_role="1217"  role="Physiatrist"></base>
<base id_role="1218"  role="Psychometrician"></base>
<base id_role="1219"  role="Pulmonary Function Technician"></base>
<base id_role="1220"  role="Sample Coordinator"></base>
<base id_role="1221"  role="Telephone Interviewer"></base>
<base id_role="1222"  role="Thoracic Surgeon"></base>
<base id_role="1223"  role="Transport Coordinator"></base>
<base id_role="1224"  role="Trauma Nurse"></base>
<base id_role="1225"  role="Trauma Surgeon"></base>
<base id_role="1226"  role="Traveling Nurse"></base>
<base id_role="1227"  role="Wellness Specialist"></base>
<base id_role="1228"  role="Bingo Attendant"></base>
<base id_role="1229"  role="Bingo Manager"></base>
<base id_role="1230"  role="Count Room Clerk"></base>
<base id_role="1231"  role="Elevator Operator"></base>
<base id_role="1232"  role="Entertainment Manager"></base>
<base id_role="1233"  role="Games Supervisor"></base>
<base id_role="1234"  role="General Assistant"></base>
<base id_role="1235"  role="General Manager - Hotel"></base>
<base id_role="1236"  role="Guest Attendant"></base>
<base id_role="1237"  role="Masseuse"></base>
<base id_role="1238"  role="Mini Bar Attendant"></base>
<base id_role="1239"  role="Pit Clerk"></base>
<base id_role="1240"  role="Pit Manager"></base>
<base id_role="1241"  role="Player Development Manager"></base>
<base id_role="1242"  role="Slot Floor Person"></base>
<base id_role="1243"  role="Slot Manager"></base>
<base id_role="1244"  role="Table Games Supervisor"></base>
<base id_role="1245"  role="Chief Diversity Officer"></base>
<base id_role="1246"  role="DB/DC Specialist"></base>
<base id_role="1247"  role="Director Compensation"></base>
<base id_role="1248"  role="Health and Wellness Specialist"></base>
<base id_role="1249"  role="Labor Relations Manager"></base>
<base id_role="1250"  role="Leadership Development Consultant"></base>
<base id_role="1251"  role="Leave Of Absence Administrator"></base>
<base id_role="1252"  role="Organization Development Consultant"></base>
<base id_role="1253"  role="Pension Specialist"></base>
<base id_role="1254"  role="PMO Manager"></base>
<base id_role="1255"  role="Senior Human Resources Generalist"></base>
<base id_role="1256"  role="Senior Human Resources Manager"></base>
<base id_role="1257"  role="Wellness Manager"></base>
<base id_role="1258"  role="Workforce Specialist"></base>
<base id_role="1259"  role="CISO"></base>
<base id_role="1260"  role="Data Collector"></base>
<base id_role="1261"  role="Data Developer"></base>
<base id_role="1262"  role="Database Specialist"></base>
<base id_role="1263"  role="Embedded Engineer"></base>
<base id_role="1264"  role="Embedded Software Developer"></base>
<base id_role="1265"  role="Ethical Hacker"></base>
<base id_role="1266"  role="Game Programmer"></base>
<base id_role="1267"  role="Informaticist"></base>
<base id_role="1268"  role="Information Technology Analyst"></base>
<base id_role="1269"  role="Intrusion Anlalyst"></base>
<base id_role="1270"  role="IT Director"></base>
<base id_role="1271"  role="Managing Consultant"></base>
<base id_role="1272"  role="Network Security Engineer"></base>
<base id_role="1273"  role="PC Technician"></base>
<base id_role="1274"  role="PL/SQL Developer"></base>
<base id_role="1275"  role="Server Administrator"></base>
<base id_role="1276"  role="Software Specialist"></base>
<base id_role="1277"  role="Software Validation Engineer"></base>
<base id_role="1278"  role="Strategic Business Partner"></base>
<base id_role="1279"  role="Systems Assistant"></base>
<base id_role="1280"  role="Telecom Manager"></base>
<base id_role="1281"  role="Telecom Specialist"></base>
<base id_role="1282"  role="Testing Manager"></base>
<base id_role="1283"  role="Threat Analyst"></base>
<base id_role="1284"  role="Unix Administrator"></base>
<base id_role="1285"  role="Virtualization Administrator"></base>
<base id_role="1286"  role="Vulnerability Analyst"></base>
<base id_role="1287"  role="Agronomist"></base>
<base id_role="1288"  role="Assembly Line Manager"></base>
<base id_role="1289"  role="Auxiliary Operator"></base>
<base id_role="1290"  role="Control Room Operator"></base>
<base id_role="1291"  role="Fork Lift Operator"></base>
<base id_role="1292"  role="Industrial Engineering Technician"></base>
<base id_role="1293"  role="Materials Planner"></base>
<base id_role="1294"  role="Oil Changer"></base>
<base id_role="1295"  role="Operations Clerk"></base>
<base id_role="1296"  role="Operator Assistant"></base>
<base id_role="1297"  role="Pipeline Operator"></base>
<base id_role="1298"  role="Pipeline Technician"></base>
<base id_role="1299"  role="Print Operator"></base>
<base id_role="1300"  role="Printing Machine Operator"></base>
<base id_role="1301"  role="Production Painter"></base>
<base id_role="1302"  role="Roadie"></base>
<base id_role="1303"  role="Robot Operator"></base>
<base id_role="1304"  role="Site Foreman"></base>
<base id_role="1305"  role="Tool Crib Attendant"></base>
<base id_role="1306"  role="Tool Room Supervisor"></base>
<base id_role="1307"  role="Chief Marketing Officer"></base>
<base id_role="1308"  role="Photographer Assistant"></base>
<base id_role="1309"  role="Floral Clerk"></base>
<base id_role="1310"  role="Grocery Buyer"></base>
<base id_role="1311"  role="Luxury Sales Manager"></base>
<base id_role="1312"  role="CRM Administrator"></base>
<base id_role="1313"  role="Key Account Executive"></base>
<base id_role="1314"  role="Product Sales Representative"></base>
<base id_role="1315"  role="Security Administrator"></base>
<base id_role="1316"  role="Security Assistant"></base>
<base id_role="1317"  role="Security Patrol"></base>
<base id_role="1318"  role="Security Technician"></base>
<base id_role="1319"  role="Surveillance Manager"></base>
<base id_role="1320"  role="Surveillance Technician"></base>
<base id_role="1321"  role="Apprentice Lineman"></base>
<base id_role="1322"  role="Apprentice Pipe Fitter"></base>
<base id_role="1323"  role="Apprentice Pipefitter"></base>
<base id_role="1324"  role="Apprentice Welder"></base>
<base id_role="1325"  role="Diagnostic Technician"></base>
<base id_role="1326"  role="Hoist Operator"></base>
<base id_role="1327"  role="Iron Worker"></base>
<base id_role="1328"  role="Joiner"></base>
<base id_role="1329"  role="Journeyman Lineman"></base>
<base id_role="1330"  role="Journeyman Mason"></base>
<base id_role="1331"  role="Journeyperson Electrician"></base>
<base id_role="1332"  role="Lead Electrician"></base>
<base id_role="1333"  role="Master Carpenter"></base>
<base id_role="1334"  role="Model Maker"></base>
<base id_role="1335"  role="Rod Buster"></base>
<base id_role="1336"  role="Roof Lead"></base>
<base id_role="1337"  role="Steamfitter"></base>
<base id_role="1338"  role="Sailor"></base>
<base id_role="1339"  role="Supply Chain Director"></base>
<base id_role="1340"  role="Traffic Clerk"></base>
<base id_role="1341"  role="Transportation Analyst"></base>
<base id_role="1342"  role="Transportation Broker"></base>
<base id_role="1343"  role="Performance Specialist"></base>
<base id_role="1344"  role="Technology Analyst"></base>
<base id_role="1345"  role="Service Desk Representative"></base>
<base id_role="1346"  role="Shared Services Manager"></base>
<base id_role="1347"  role="Archivist"></base>
<base id_role="1348"  role="Booking Manager"></base>
<base id_role="1349"  role="Casting Director"></base>
<base id_role="1350"  role="Concept Artist"></base>
<base id_role="1351"  role="Conservator"></base>
<base id_role="1352"  role="Driving Range Attendant"></base>
<base id_role="1353"  role="Exhibit Specialist"></base>
<base id_role="1354"  role="Fundraising Agent"></base>
<base id_role="1355"  role="Gallery Attendant"></base>
<base id_role="1356"  role="Gallery Coordinator"></base>
<base id_role="1357"  role="Gallery Staff"></base>
<base id_role="1358"  role="Game Artist"></base>
<base id_role="1359"  role="Game Developer"></base>
<base id_role="1360"  role="Golf Course Manager"></base>
<base id_role="1361"  role="Golf Staff"></base>
<base id_role="1362"  role="Light Technician"></base>
<base id_role="1363"  role="Lighting Manager"></base>
<base id_role="1364"  role="Localization Specialist"></base>
<base id_role="1365"  role="Officiant"></base>
<base id_role="1366"  role="Ride Mechanic"></base>
<base id_role="1367"  role="Studio Technician"></base>
<base id_role="1368"  role="Theater Specialist"></base>
<base id_role="1369"  role="Video Production Specialist"></base>
<base id_role="1370"  role="Custodial Manager"></base>
<base id_role="1371"  role="Senior Custodian"></base>
<base id_role="1372"  role="Bankruptcy Specialist"></base>
<base id_role="1373"  role="Commercial Loan Officer"></base>
<base id_role="1374"  role="Director of Internal Audit"></base>
<base id_role="1375"  role="Financial Services Producer"></base>
<base id_role="1376"  role="Investment Relations Manager"></base>
<base id_role="1377"  role="Land Agent"></base>
<base id_role="1378"  role="Retirement Specialist"></base>
<base id_role="1379"  role="Senior Tax Analyst"></base>
<base id_role="1380"  role="Showing Specialist"></base>
<base id_role="1381"  role="Stock Broker"></base>
<base id_role="1382"  role="Title Coordinator"></base>
<base id_role="1383"  role="Trading Specialist"></base>
<base id_role="1384"  role="Universal Associate"></base>
<base id_role="1385"  role="VP Investment Banking"></base>
<base id_role="1386"  role="Room Service Manager"></base>
<base id_role="1387"  role="Admixture Tech"></base>
<base id_role="1388"  role="Cardiac Electrophysiologist"></base>
<base id_role="1389"  role="Cardiology Technician"></base>
<base id_role="1390"  role="Clinical Care Technician"></base>
<base id_role="1391"  role="Community Education Specialist"></base>
<base id_role="1392"  role="Gynecologist"></base>
<base id_role="1393"  role="Healthcare Analyst"></base>
<base id_role="1394"  role="Healthcare Representative"></base>
<base id_role="1395"  role="Hospice Administrator"></base>
<base id_role="1396"  role="Kinesiologist"></base>
<base id_role="1397"  role="Medical Monitor"></base>
<base id_role="1398"  role="Medical Review Specialist"></base>
<base id_role="1399"  role="Neurophysiologist"></base>
<base id_role="1400"  role="Obstetrician"></base>
<base id_role="1401"  role="Otolaryngologist"></base>
<base id_role="1402"  role="Perinatologist"></base>
<base id_role="1403"  role="Perioperative Aide"></base>
<base id_role="1404"  role="Surgery Aide"></base>
<base id_role="1405"  role="Telehealth Nurse"></base>
<base id_role="1406"  role="General Worker"></base>
<base id_role="1407"  role="Golf Coordinator"></base>
<base id_role="1408"  role="Keno Runner"></base>
<base id_role="1409"  role="Reservation Clerk"></base>
<base id_role="1410"  role="Soft Count Clerk"></base>
<base id_role="1411"  role="Uniform Attendant"></base>
<base id_role="1412"  role="Waterfront Director"></base>
<base id_role="1413"  role="Director Change Management"></base>
<base id_role="1414"  role="Labor Relations Specialist"></base>
<base id_role="1415"  role="Chief Data Officer"></base>
<base id_role="1416"  role="CIO"></base>
<base id_role="1417"  role="Data Analytics Manager"></base>
<base id_role="1418"  role="Data Center Specialist"></base>
<base id_role="1419"  role="Disaster Recovery Analyst"></base>
<base id_role="1420"  role="Forensics Specialist"></base>
<base id_role="1421"  role="IT Risk Analyst"></base>
<base id_role="1422"  role="Cutting Technician"></base>
<base id_role="1423"  role="Machine Shop Maintenance Supervisor"></base>
<base id_role="1424"  role="Materials Control Manager"></base>
<base id_role="1425"  role="Pipeline Manager"></base>
<base id_role="1426"  role="Road Crew"></base>
<base id_role="1427"  role="Stress Test Technician"></base>
<base id_role="1428"  role="Community Specialist"></base>
<base id_role="1429"  role="Gift Shop Clerk"></base>
<base id_role="1430"  role="Renewable Energy Specialist"></base>
<base id_role="1431"  role="VP Development"></base>
<base id_role="1432"  role="Security Investigator"></base>
<base id_role="1433"  role="Electromechanical Technician"></base>
<base id_role="1434"  role="Journeyman HVAC Technician"></base>
<base id_role="1435"  role="Journeyman Pipe Fitter"></base>
<base id_role="1436"  role="Journeyman Steamfitter"></base>
<base id_role="1437"  role="Pipe Fitter Helper"></base>
<base id_role="1438"  role="Roofer Helper"></base>
<base id_role="1439"  role="Wind Energy Specialist"></base>
<base id_role="1440"  role="Merchant Mariner"></base>
<base id_role="1441"  role="Reporting Developer"></base>
<base id_role="1442"  role="Art Consultant"></base>
<base id_role="1443"  role="Audiovisual Specialist"></base>
<base id_role="1444"  role="Costume Specialist"></base>
<base id_role="1445"  role="Lighting Supervisor"></base>
<base id_role="1446"  role="Museum Assistant"></base>
<base id_role="1447"  role="Park Services Specialist"></base>
<base id_role="1448"  role="Philanthropy Director"></base>
<base id_role="1449"  role="Players Club Manager"></base>
<base id_role="1450"  role="Ride Technician"></base>
<base id_role="1451"  role="Storyboard Artist"></base>
<base id_role="1452"  role="VIP Host"></base>
<base id_role="1453"  role="Weather Anchor"></base>
<base id_role="1454"  role="Zoo Keeper"></base>
<base id_role="1455"  role="Commodity Trader"></base>
<base id_role="1456"  role="Conservation Specialist"></base>
<base id_role="1457"  role="Director Lending"></base>
<base id_role="1458"  role="Financial Controls Specialist"></base>
<base id_role="1459"  role="International Banking Specialist"></base>
<base id_role="1460"  role="Risk Control Specialist"></base>
<base id_role="1461"  role="Senior Budget Analyst"></base>
<base id_role="1462"  role="Senior Risk Analyst"></base>
<base id_role="1463"  role="VP Risk Management"></base>
<base id_role="1464"  role="Anesthesiologist Assistant"></base>
<base id_role="1465"  role="Clinical Services Supervisor"></base>
<base id_role="1466"  role="Electrophysiology Technician"></base>
<base id_role="1467"  role="Funding Coordinator"></base>
<base id_role="1468"  role="Healthcare Administrator"></base>
<base id_role="1469"  role="Hyperbaric Tech"></base>
<base id_role="1470"  role="Provider Coordinator"></base>
<base id_role="1471"  role="Virologist"></base>
<base id_role="1472"  role="Babysitter/Nanny"></base>
<base id_role="1473"  role="Games Manager"></base>
<base id_role="1474"  role="Gaming Inspector"></base>
<base id_role="1475"  role="Golf Superintendent"></base>
<base id_role="1476"  role="Dir Talent Management"></base>
<base id_role="1477"  role="Manager Talent Acquisition"></base>
<base id_role="1478"  role="VP Talent Management"></base>
<base id_role="1479"  role="Cyber Defense Specialist"></base>
<base id_role="1480"  role="Malware Analyst"></base>
<base id_role="1481"  role="Storage Specialist"></base>
<base id_role="1482"  role="Master Grower"></base>
<base id_role="1483"  role="Marketing Specialist"></base>
<base id_role="1484"  role="Media Supervisor"></base>
<base id_role="1485"  role="Gift Shop Manager"></base>
<base id_role="1486"  role="Apprentice HVAC Technician"></base>
<base id_role="1487"  role="Apprentice Mason"></base>
<base id_role="1488"  role="Apprentice Roofer"></base>
<base id_role="1489"  role="Journeyman Machinist"></base>
<base id_role="1490"  role="Master Mason"></base>
<base id_role="1491"  role="Structural Ironworker"></base>
<base id_role="1492"  role="Deck Officer"></base>
<base id_role="1493"  role="Associate Production Manager"></base>
<base id_role="1494"  role="Ski Patrol"></base>
<base id_role="1495"  role="Wardrobe Assistant"></base>
<base id_role="1496"  role="Director Risk Management"></base>
<base id_role="1497"  role="Investment Banker"></base>
<base id_role="1498"  role="Pricing Associate"></base>
<base id_role="1499"  role="Chemical Dependency Technician"></base>
<base id_role="1500"  role="Clinical Care Tech"></base>
<base id_role="1501"  role="Donor Technician"></base>
<base id_role="1502"  role="Legal Nurse"></base>
<base id_role="1503"  role="Pediatric Surgeon"></base>
<base id_role="1504"  role="Talent Advisor"></base>
<base id_role="1505"  role="Chief Risk Officer"></base>
<base id_role="1506"  role="Disaster Recovery Specialist"></base>
<base id_role="1507"  role="Remedy Administrator"></base>
<base id_role="1508"  role="Cheesemaker"></base>
<base id_role="1509"  role="Signal Worker"></base>
<base id_role="1510"  role="Art Director"></base>
<base id_role="1511"  role="Jewelry Manager"></base>
<base id_role="1512"  role="Electrician Assistant"></base>
<base id_role="1513"  role="Plumber Assistant"></base>
<base id_role="1514"  role="Import/Export Clerk"></base>
<base id_role="1515"  role="Senior General Manager"></base>
<base id_role="1516"  role="Gallery Assistant"></base>
<base id_role="1517"  role="Golf Pro Shop Attendant"></base>
<base id_role="1518"  role="Location Scout"></base>
<base id_role="1519"  role="Museum Manager"></base>
<base id_role="1520"  role="Ski Technician"></base>
<base id_role="1521"  role="Visiting Scholar"></base>
<base id_role="1522"  role="Wardrobe Manager"></base>
<base id_role="1523"  role="Whitewater Raft Guide"></base>
<base id_role="1524"  role="Zoo Curator"></base>
<base id_role="1525"  role="Financial Reporting Specialist"></base>
<base id_role="1526"  role="Resolutions Agent"></base>
<base id_role="1527"  role="VP Investor Relations"></base>
<base id_role="1528"  role="Immunologist"></base>
<base id_role="1529"  role="Opthalmic Assistant"></base>
<base id_role="1530"  role="Employee Engagement Specialist"></base>
<base id_role="1531"  role="Leadership Development Manager"></base>
<base id_role="1532"  role="VP Diversity"></base>
<base id_role="1533"  role="Disaster Recovery Manager"></base>
<base id_role="1534"  role="E-commerce Manager"></base>
<base id_role="1535"  role="Apprentice Locksmith"></base>
<base id_role="1536"  role="Dry Wall Installer"></base>
<base id_role="1537"  role="Import/Export Manager"></base>
<base id_role="1538"  role="Streetcar Operator"></base>
<base id_role="1539"  role="Playwright"></base>
<base id_role="1540"  role="Medical Geneticist"></base>
<base id_role="1541"  role="Back of House Team Member"></base>
<base id_role="1542"  role="Coaching Specialist"></base>
<base id_role="1543"  role="Director Talent Acquisition"></base>
<base id_role="1544"  role="Rewards Specialist"></base>
<base id_role="1545"  role="Implementation Planner"></base>
<base id_role="1546"  role="Fashion Manager"></base>
<base id_role="1547"  role="Master Painter"></base>
<base id_role="1548"  role="Risk Auditor"></base>
<base id_role="1549"  role="Healthcare Interpreter"></base>
<base id_role="1550"  role="Commercial Real Estate Advisor"></base>
<base id_role="1551"  role="Financial Modeler"></base>
<base id_role="1552"  role="Trade Assistant"></base>
<base id_role="1553"  role="Slot Floor Technician"></base>
<base id_role="1554"  role="Executive Compensation Specialist"></base>
<base id_role="1555"  role="Cognos Administrator"></base>
<base id_role="1556"  role="Intrusion Analyst"></base>
<base id_role="1557"  role="IOT Architect"></base>
<base id_role="1558"  role="Philanthropy Specialist"></base>
<base id_role="1559"  role="Snowboard Instructor"></base>
<base id_role="1560"  role="Case Management Team"></base>
<base id_role="1561"  role="Electrodiagnostic Technician"></base>
<base id_role="1562"  role="Medicare Analyst"></base>
<base id_role="1563"  role="Uniform Manager"></base>
<base id_role="1564"  role="Director Talent Management"></base>
<base id_role="1565"  role="Floral Supervisor"></base>
<base id_role="1566"  role="Localization Coordinator"></base>
<base id_role="1567"  role="Makeup Director"></base>
<base id_role="1568"  role="Senior Compliance Officer"></base>
<base id_role="1569"  role="Virtual Adjuster"></base>
<base id_role="1570"  role="VP Retail Banking"></base>
<base id_role="1571"  role="Oncology Technician"></base>
<base id_role="1572"  role="Leadership Development Specialist"></base>
<base id_role="1573"  role="Performance Management Specialist"></base>
<base id_role="1574"  role="VP HR Ops/SS"></base>
<base id_role="1575"  role=".Net Specialist"></base>
<base id_role="1576"  role="Software Assistant"></base>
<base id_role="1577"  role="Journeyman Boilermaker"></base>
<base id_role="1578"  role="Golf Course Supervisor"></base>
<base id_role="1579"  role="Localization Manager"></base>
<base id_role="1580"  role="Music Executive"></base>
<base id_role="1581"  role="Video Designer"></base>
<base id_role="1582"  role="International Service Specialist"></base>
<base id_role="1583"  role="Virtual Insurance Agent"></base>
<base id_role="1584"  role="Golf Greenskeeper"></base>
<base id_role="1585"  role="Leave Of Absence Specialist"></base>
<base id_role="1586"  role="Waste Treatment Plant Operator"></base>
<base id_role="1587"  role="Motorboat Operator"></base>
<base id_role="1588"  role="Sports Agent"></base>
<base id_role="1589"  role="Site Development Manager"></base>
<base id_role="1590"  role="Mortgage Auditor"></base>
<base id_role="1591"  role="Serologist"></base>
<base id_role="1592"  role="Poker Room Manager"></base>
<base id_role="1593"  role="Fashion Associate"></base>
<base id_role="1594"  role="Makeup Stylist"></base>
<base id_role="1595"  role="Gerontologist"></base>
<base id_role="1596"  role="Reproductive Endocrinologist"></base>
<base id_role="1597"  role="Embedded Architect"></base>
<base id_role="1598"  role="HVAC Operator"></base>
<base id_role="1599"  role="VIP Services Manager"></base>
<base id_role="1600"  role="Online Banking Specialist"></base>
<base id_role="1601"  role="Behavior Modification Therapist"></base>
<base id_role="1602"  role="Registered Practical Nurse"></base>
<base id_role="1603"  role="General Manager - Casino"></base>
<base id_role="1604"  role="Truck Driver Supervisor"></base>
<base id_role="1605"  role="Debt Negotiator"></base>
<base id_role="1606"  role="Principal Researcher"></base>
<base id_role="1607"  role="Director of Leadership Development"></base>
<base id_role="1608"  role="Derivatives Analyst"></base>
<base id_role="1609"  role="Intraoperative Monitoring Technician"></base>
<base id_role="1610"  role="Guest Experience Rep"></base>
<base id_role="1611"  role="DB2 Administrator"></base>
<base id_role="1612"  role="Investment Banking Principal"></base>
<base id_role="1613"  role="VP Total Rewards"></base>
<base id_role="1614"  role="Business Object Administrator"></base>
<base id_role="1615"  role="WebSphere Developer"></base>
<base id_role="1616"  role="Chemical Health Assessor"></base>
<base id_role="1617"  role="Cardiology Technologist"></base>
<base id_role="1618"  role="Merger Integration Consultant"></base>
<base id_role="1619"  role="Lawn Service Manager"></base>
<base id_role="1620"  role="Cinema Manager"></base>
<base id_role="1621"  role="Sound Manager"></base>
<base id_role="1622"  role="Journeyman Locksmith"></base>
<base id_role="1623"  role="Management Reporting Analyst"></base>
<base id_role="1624"  role="Virtual Banking Representative"></base>
<base id_role="1625"  role="Drop Count Supervisor"></base>
<base id_role="1626"  role="Equity Program Specialist"></base>
<base id_role="1627"  role="Merchandizing Manager"></base>
<base id_role="1628"  role="Master Welder"></base>
<base id_role="1629"  role="Machine Shop Production Supervisor"></base>
<base id_role="1630"  role="Cryptocurrency Broker"></base>
<base id_role="1631"  role="Video Game Producer"></base>
<base id_role="1632"  role="Bounty Hunter"></base>
<base id_role="1633"  role="Mortage Loan Originator"></base>
<base id_role="1634"  role="Quant Trader"></base>
<base id_role="1635"  role="Senior Financial Reporting Manager"></base>
<base id_role="1636"  role="Bond Trader"></base>
<base id_role="1637"  role="Post Production Coordinator"></base>
<base id_role="1638"  role="Floor Assembler"></base>
<base id_role="1639"  role="Health Safety Manager"></base>
<base id_role="1640"  role="Hard Count Clerk"></base>
<base id_role="1641"  role="Powerhouse Supervisor"></base>
<base id_role="1642"  role="Inclusion and Diversity Manager"></base>
<base id_role="1643"  role="Marine Oiler"></base>
<base id_role="1644"  role="Game Tester"></base>
<base id_role="1645"  role="Futures Trader"></base>
<base id_role="1646"  role="OBIEE Administrator"></base>
<base id_role="1647"  role="PL/SQL Architect"></base>
<base id_role="1648"  role="Cage and Vault Manager"></base>
<base id_role="1649"  role="Renewable Energy Engineer"></base>
<base id_role="1650"  role="Quality Administration"></base>
<base id_role="1651"  role="Journeyman Iron Worker"></base>
<base id_role="1652"  role="Business Risk and Controls Advisor"></base>
<base id_role="1653"  role="VP Asset Management"></base>
<base id_role="1654"  role="Commodities Analyst"></base>
<base id_role="1655"  role="PL/SQL Analyst"></base>
<base id_role="1656"  role="Turf Mechanic"></base>
<base id_role="1657"  role="VP Land Development"></base>
<base id_role="1658"  role="Zoo Ranger"></base>
<base id_role="1659"  role="Jig And Fixture Builder"></base>
<base id_role="1660"  role="Media Exploitation Analyst"></base>
<base id_role="1661"  role="Ropes Facilitator"></base>
<base id_role="1662"  role="Master Pipe Fitter"></base>
<base id_role="1663"  role="Permitting Agent"></base>
<base id_role="1664"  role="Diversity Consultant"></base>
<base id_role="1665"  role="ORACLE Administrator"></base>
<base id_role="1666"  role="Blocklayer"></base>
<base id_role="1667"  role="Stadium Manager"></base>
<base id_role="1668"  role="Video Game Specialist"></base>
<base id_role="1669"  role="Roofer Assistant"></base>
<base id_role="1670"  role="Prosthetics Technician"></base>
<base id_role="1671"  role="Securities Trader"></base>
<base id_role="1672"  role="Conference Services Attendant"></base>
<base id_role="1673"  role="VP Commercial Lending"></base>
<base id_role="1674"  role="Games Director"></base>
<base id_role="1675"  role="Master Machinist"></base>
<base id_role="1676"  role="Cage and Vault Cashier"></base>
<base id_role="1677"  role="Movie Producer"></base>
<base id_role="1678"  role="Film Executive"></base>
<base id_role="1679"  role="Snow Maker"></base>
<base id_role="1680"  role="Influencer Specialist"></base>
<base id_role="1681"  role="Status Board Operator"></base>
<base id_role="1682"  role="Room Sales Representative"></base>
<base id_role="1683"  role="Apprentice Iron Worker"></base>
<base id_role="1684"  role="Cryptographer"></base>
<base id_role="1685"  role="Site Coordinator"></base>
<base id_role="1686"  role="Sellers Agent"></base>
<base id_role="1687"  role="Chief Analytics Officer"></base>
<base id_role="1688"  role="Apprentice Boilermaker"></base>
<base id_role="1689"  role="Organ Procurement Technician"></base>
<base id_role="1690"  role="Pre Production Coordinator"></base>
<base id_role="1691"  role="Disk Jockey"></base>
<base id_role="1692"  role="Lyricist"></base>
<base id_role="1693"  role="Investigation Assistant"></base>
<base id_role="1694"  role="Croupier"></base>
<base id_role="1695"  role="Dir HR Strategy"></base>
<base id_role="1696"  role="Report Administrator"></base>
<base id_role="1697"  role="Concert Manager"></base>
<base id_role="1698"  role="Choir Manager"></base>
<base id_role="1699"  role="Convention Manager"></base>
<base id_role="1700"  role="Lighting Director"></base>
</Bases>'



;WITH datos AS (
    SELECT T.N.value('./@id_role','INT') id_role
    ,T.N.value('./@role','VARCHAR(100)') Role
    FROM   @xdoc.nodes('/Bases/base') T(N)  
)  INSERT INTO "Role" (id_role,"Role") SELECT * FROM datos;

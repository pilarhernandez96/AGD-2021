DROP TABLE IF EXISTS industry;
CREATE TABLE [industry] (
  [id_Indt] Int primary key,
  [Industry] Varchar(50),
);

DECLARE @xdoc xml   
SET @xdoc='
<Bases>
<base ID="1"  industry="Communication"></base>
<base ID="2"  industry="Construction"></base>
<base ID="3"  industry="Energy"></base>
<base ID="4"  industry="Entertainment"></base>
<base ID="5"  industry="Financial Services"></base>
<base ID="6"  industry="Healthcare"></base>
<base ID="7"  industry="Hospitality"></base>
<base ID="8"  industry="Insurance"></base>
<base ID="9"  industry="Manufacturing"></base>
<base ID="10"  industry="Mining"></base>
<base ID="11"  industry="Real Estate"></base>
<base ID="12"  industry="Retail"></base>
<base ID="13"  industry="Services"></base>
<base ID="14"  industry="Transportation"></base>
<base ID="15"  industry="Wholesale"></base>
</Bases>'

;WITH datos AS (
    SELECT T.N.value('./@ID','INT') id_Indt
    ,T.N.value('./@industry','VARCHAR(50)') Industry
    FROM   @xdoc.nodes('/Bases/base') T(N)  
)  INSERT INTO industry (id_Indt,Industry) SELECT * FROM datos;